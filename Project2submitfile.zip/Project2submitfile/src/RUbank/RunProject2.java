package RUbank;

/**
 * Driver to run Project 2.
 * @author Vinh Pham
 */

public class RunProject2 {
    public static void main(String[] args) {
        TransactionManager main = new TransactionManager();
        main.run();
    }
}